# Pronocludix (Starter)

Un squelette *statique* pour démarrer un site de pronostics sportifs et l'héberger avec **GitHub Pages**.

## Démarrer

1. Ouvrez ce dossier dans votre éditeur (ou GitHub Desktop).
2. Modifiez `index.html`, `styles.css`, `script.js` selon vos besoins.
3. Publiez sur GitHub, puis activez **Settings → Pages** (branch `main`, dossier `/root`).

## Fonctions incluses
- Ajout de tickets (événement, marché, cote, mise).
- Calcul automatique du gain potentiel.
- Suivi du statut (ouvert / gagné / perdu).
- Stockage local (LocalStorage) pour mémoriser vos tickets.
- Section Bankroll avec calcul de mise recommandée (pourcentage fixe).
- Exemple de liste de matchs (statique).

## Aller plus loin
- Remplacer la liste statique par une API (odds, fixtures).
- Ajouter un export CSV de vos tickets.
- Mettre un design aux couleurs de votre marque.
