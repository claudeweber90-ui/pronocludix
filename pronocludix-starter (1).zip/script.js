// Gestion tickets / calculs
const tickets = JSON.parse(localStorage.getItem('pronocludix_tickets') || '[]');
const tbody = document.querySelector('#tickets-table tbody');
const form = document.getElementById('ticket-form');
const yearSpan = document.getElementById('year');

function renderTickets(){
  tbody.innerHTML = '';
  tickets.forEach((t, idx) => {
    const tr = document.createElement('tr');
    const potential = (t.odds * t.stake).toFixed(2);
    tr.innerHTML = `
      <td>${t.event}</td>
      <td>${t.market}</td>
      <td>${t.odds.toFixed(2)}</td>
      <td>${t.stake.toFixed(2)}</td>
      <td>${potential}</td>
      <td>
        <select data-idx="${idx}">
          <option value="ouvert" ${t.status==='ouvert'?'selected':''}>Ouvert</option>
          <option value="gagné" ${t.status==='gagné'?'selected':''}>Gagné</option>
          <option value="perdu" ${t.status==='perdu'?'selected':''}>Perdu</option>
        </select>
      </td>
      <td><button data-del="${idx}">✕</button></td>
    `;
    tbody.appendChild(tr);
  });
  localStorage.setItem('pronocludix_tickets', JSON.stringify(tickets));
}

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const data = new FormData(form);
  const event = data.get('event').trim();
  const market = data.get('market').trim();
  const odds = parseFloat(data.get('odds'));
  const stake = parseFloat(data.get('stake'));
  if(!event || !market || isNaN(odds) || isNaN(stake)) return;
  tickets.push({ event, market, odds, stake, status: 'ouvert' });
  form.reset();
  renderTickets();
});

tbody.addEventListener('change', (e) => {
  if(e.target.tagName === 'SELECT'){
    const i = e.target.getAttribute('data-idx');
    tickets[i].status = e.target.value;
    renderTickets();
  }
});
tbody.addEventListener('click', (e) => {
  if(e.target.tagName === 'BUTTON' && e.target.hasAttribute('data-del')){
    const i = e.target.getAttribute('data-del');
    tickets.splice(i, 1);
    renderTickets();
  }
});

// Bankroll calc (Kelly simple approximation: f = p - (1-p)/b if p provided – ici % fixe)
document.getElementById('calc-stake').addEventListener('click', () => {
  const start = parseFloat(document.getElementById('bankroll-start').value || '0');
  const pct = parseFloat(document.getElementById('stake-pct').value || '0');
  const stake = (start * pct / 100);
  const out = document.getElementById('stake-output');
  out.textContent = `Mise conseillée: €${stake.toFixed(2)} (${pct}% de €${start.toFixed(2)})`;
});

yearSpan.textContent = new Date().getFullYear();

// Initial render
renderTickets();
